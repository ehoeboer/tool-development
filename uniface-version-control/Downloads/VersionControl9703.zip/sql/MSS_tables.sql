create table [vc_status]
(
 [filepath] nvarchar(256) not null,
 [repository_dt] datetime null,
 [filemod_dt] datetime null,
 [lastimport_rev] numeric(21,0) null,

 constraint [vc_status_pk] primary key 
  ([filepath])
)

grant delete, insert, references, select, update on [vc_status]
 to public

go

